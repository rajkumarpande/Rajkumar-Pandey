package com.javatpoint;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
@RequestMapping("/reservation")  

@Controller  

public class NumberController {
@RequestMapping("/ctr1")
public String numberForm(Model model) {
	Number num= new Number();
	
	model.addAttribute("reservation",num);
	return "page1";
}

@RequestMapping("/submitForm")
public String displayForm(@ModelAttribute("reservation") Number num) {
	int i=num.getNumber();
	if(i % 2 == 0) {
	return  "page2";
	}
	else
		return "page3";

	}
		
}


